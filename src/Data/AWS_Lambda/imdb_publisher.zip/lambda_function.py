import json
import boto3
import csv
import time
from io import TextIOWrapper

def lambda_handler(event, context):
    print (event)
    imdbGenerationRequest = {}
    imdbGenerationRequest['outputBucket'] = 'w266-final-project'
    imdbGenerationRequest['outputKey'] = 'thumbnails/'

    content = {}
    s3 = boto3.resource('s3')
    SQS = boto3.client("sqs")
    s3Record = event['Records'][0]
    s3Bucket = s3Record['s3']['bucket']['name']
    s3Key = s3Record['s3']['object']['key']
    s3Object = s3.Object(s3Bucket, s3Key)
    body = s3Object.get()['Body'].read().splitlines(True)
    
    sqsQueue = "imdb_publisher_queue"
    sqsQueueUrl = SQS.get_queue_url(QueueName=sqsQueue).get('QueueUrl')
    for items in body:
        print(items.decode("utf-8").strip())
        imdbId = items.decode("utf-8").strip()
        imdbGenerationRequest['movie_id'] = imdbId
        imdbGenerationRequest['movie_url'] = "https://www.imdb.com/title/" + str(imdbId) + "/"
        
        print (imdbGenerationRequest)
        resp = SQS.send_message(QueueUrl=sqsQueueUrl, MessageBody=json.dumps(imdbGenerationRequest))
    
    return {
        'statusCode': 200,
        'body': json.dumps(imdbGenerationRequest)
    }