import sys
sys.path.append( '/opt/')
import urllib.request, urllib.error
import json
from bs4 import BeautifulSoup
import requests
import boto3
import os
import re

def lambda_handler(event, context):
    
    for record in event['Records']:
        print(record)
        payload=json.loads(record['body'])
        #payload=(record['body'])

        print(payload)
        movie_id = payload['movie_id']
        outputBucket = payload['outputBucket']
        outputKey = payload['outputKey']
        movie_url = payload['movie_url']
        movie_plot_url = payload['movie_plot_url']

        json_output  = None
        json_plot_summary = None
        with urllib.request.urlopen(movie_url) as response:
            try:
                html = response.read()
                soup = BeautifulSoup(html, 'html.parser')

                try:
                    print(movie_id)
                    thumbnail_url = "https://w266-final-project.s3.amazonaws.com/thumbnails/" + str(movie_id) + ".jpg"
                    try:
                        movie_data = soup.find('div', class_='title_wrapper').h1.text
                        movie_name = re.sub("[\(\[].*?[\)\]]", '', movie_data).strip()
                        print(movie_name)
                    except:
                        movie_name = ''
                        print('Exception in movie_name')
                        #print(soup)
                        #print(soup.find('div', class_='title_wrapper').h1.text)
                        
                    try:
                        movie_year = soup.find('div', class_='title_wrapper').span.text
                        movie_year = re.sub('[(){}<>]', '', movie_year).strip()
                        print(movie_year)
                    except:
                        movie_year = ''
                        print('Exception in movie_year')

                    list_divs = soup.find_all('div',class_='see-more inline canwrap')
                    
                    try:
                        genre_list = []
                        for curr_div in list_divs:
                            if curr_div.h4.text == 'Genres:':
                                genre_list = [genre.text.strip() for genre in curr_div.find_all('a')]
                        print(genre_list)
                    except:
                        genre_list = []
                        print('Exception in genre list')
                        
                    list_divs = soup.find_all('div', class_='txt-block')
                    language = ''
                    try:
                        for curr_div in list_divs:
                            if curr_div.h4.text == 'Language:':
                                language = curr_div.find('a').text.strip()
                        print(language)
                    except:
                        print('Exception in language')

                    json_output = {'MovieID':movie_id,
                                   'MovieName':movie_name,
                                   'Year':movie_year,
                                   'Genre':genre_list,
                                   'Language':language,
                                   'Thumbnail':thumbnail_url}

                except:
                    json_output = None
                    print('Skipped...' + str(movie_id))
            except:
                json_output = None
                print('totally skipped...' + str(movie_id))

        if json_output is not None:

            with urllib.request.urlopen(movie_plot_url) as response:
                try:
                    html = response.read()
                    soup = BeautifulSoup(html, 'html.parser')
                    try:
                        plot_summary_el = soup.find('ul', {'class': 'ipl-zebra-list', 'id': 'plot-summaries-content'})
                        summaries = plot_summary_el.find_all('li')
                        longest_summary = ''
                        for summary in summaries:
                            plot = summary.p.text.strip()
                            if len(plot) > len(longest_summary):
                                longest_summary = plot
                        # This is our relevant summary
                        print(longest_summary)
                        json_plot_summary = longest_summary
                        json_output['MoviePlot'] = longest_summary
                    except:
                        json_plot_summary = None
                        print('Skipped movie plot...' + str(movie_id))
                except:
                    json_plot_summary = None
                    print('Totally skipped movie plot...' + str(movie_id))

        if (json_output is not None) and (json_plot_summary is not None):
            # Do the actual upload to s3
            s3 = boto3.resource('s3')
            s3object = s3.Object(outputBucket, outputKey+movie_id+'.json')
            s3object.put(Body=(bytes(json.dumps(json_output).encode('UTF-8'))))
