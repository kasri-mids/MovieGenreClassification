import sys
sys.path.append( '/opt/')
import urllib.request, urllib.error
import json
from bs4 import BeautifulSoup
import requests
import boto3
import os

def lambda_handler(event, context):
    
    for record in event['Records']:
        print(record)
        payload=json.loads(record['body'])
        #payload=(record['body'])

        print(payload)
        movie_id = payload['movie_id']
        outputBucket = payload['outputBucket']
        outputKey = payload['outputKey']
        movie_url = payload['movie_url']

        with urllib.request.urlopen(movie_url) as response:
            try:
                html = response.read()
                soup = BeautifulSoup(html, 'html.parser')
        
                # Get url of poster image
                try:
                    image_url = soup.find('div', class_='poster').a.img['src']
                    # Hard coded the extension
                    extension = '.jpg'
                    image_url = ''.join(image_url.partition('_')[0]) + extension
                except AttributeError:
                  image_url = None
                  print('Could not get image from ')
            except:
                image_url = None
                print('Errored out')
        print(image_url)
        if image_url is not None:
            req_for_image = requests.get(image_url, stream=True)
            # Given an Internet-accessible URL, download the image and upload it to S3,
            # without needing to persist the image to disk locally
            file_object_from_req = req_for_image.raw
            req_data = file_object_from_req.read()
        
            # Do the actual upload to s3
            s3 = boto3.resource('s3')
            s3.Bucket(outputBucket).put_object(Key=outputKey+movie_id+'.jpg', Body=req_data)